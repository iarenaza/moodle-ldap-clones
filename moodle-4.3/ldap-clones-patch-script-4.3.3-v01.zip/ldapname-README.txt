
Make sure 'ldapname.diff' and 'ldapname.php' are at the top directory
of your Moodle installation (i.e., the directory where 'config.php'
is). Also, make sure the `patch` executable is in your path (or
`patch.exe` is in your PATH, if you are using MS Windows).

In order to apply the patch you just need to perform a single step:
execute the 'ldapname.php' script with the name of the new cloned
plugin. The following example uses 'ldap2' as the name for the new
cloned plugin:

    php ldapname.php ldap2

The 'ldapname.php' script will check that the new cloned plugin name
complies with Moodle plugin naming rules. Otherwise it may have an
erratic behavior (i.e., some things may work while others not). If
the name doesn't comply with the rules, it will print an error and
stop its execution.

Saludos.

Iñaki

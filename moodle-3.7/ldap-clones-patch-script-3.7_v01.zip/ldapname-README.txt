
Make sure 'ldapname.diff' and 'ldapname.php' are at the top directory
of your Moodle installation (i.e., the directory where 'config.php' is).

In order to apply the patch we just need to perform a single step:
execute 'ldapname.php' script. The following example uses 'ldap2' as
the name for the new cloned plugin:

    php ldapname.php ldap2

The 'ldapname.php' script will check the new cloned plugin name to make
sure it complies with Moodle plugin naming rules. Otherwise it may
have an erratic behaviour (i.e., some things working while other not).

Saludos.
Iñaki

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Authentication Plugin: LDAP Authentication
 * Authentication using LDAP (Lightweight Directory Access Protocol).
 *
 * @package ldapname
 * @author Iñaki Arenaza
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 */

define('CLI_SCRIPT', true);

function usage() {
    $script = $_SERVER['SCRIPT_NAME'];
    echo <<<END
  Syntax:
    php -f $script ldap-auth-plugin-name

  Where:
    ldap-auth-plugin-name is the name of the new LDAP auth plugin "clone"
 
    NOTE:  Only lowercase ASCII letters, numbers and underscores are
           allowed in the plugin name, and it has to start with a letter.
           But numbers and underscores are strongly discouraged by
           Moodle developers!

  Examples:
    php -f $script ldap2
    php -f $script myldap

END;
}

if ($_SERVER['argc'] < 2) {
    usage();
    exit;
}

try {
    require(dirname(__FILE__).'/config.php');
} catch (dml_connection_exception $e) {
    // Just continue, we don't need the database for this to work.
    echo "Continuing, even if database is not available\n";
}

try {
    $ldapname = validate_param($_SERVER['argv'][1], PARAM_PLUGIN);
} catch (invalid_parameter_exception $e) {
    usage();
    exit;
}

$ldapnew  = $CFG->dirroot.'/auth/'.$ldapname;
$patchfileorig = $CFG->dirroot.'/ldapname.diff';

$patchstring = file_get_contents($patchfileorig);
if (!$patchstring) {
    die ("Can't read input patch file");
}

$patchstring = str_replace('%%LDAPNAME%%', $ldapname, $patchstring);

$patchtempfile = tempnam(dirname(__FILE__), 'ldp');
if (stristr(PHP_OS, 'win') && !stristr(PHP_OS, 'darwin')) {
    $fh = fopen($patchtempfile, 'wt');
} else {
    $fh = fopen($patchtempfile, 'w');
}
if (!$fh) {
    die("Unable to create temp patch file. Exiting\n. Don't forget to remove $ldapnew directory");
}

$ret = fwrite($fh, $patchstring);
if (!$ret) {
    fclose($fh);
    unlink($patchtempfile);
    die("Unable to write to temp patch file. Exiting\n. Don't forget to remove $ldapnew directory");
}

fclose($fh);
system ('patch -p1 < "'.$patchtempfile.'" ');
unlink($patchtempfile);

echo <<<END

=====================================================================
If you are using Internet Information Server (IIS) to run your Moodle
installation, please adjust the permissions of the
$ldapnew directory.

patch.exe for Windows removes some essential permissions from the
patched files, that make some of then unreadable by IIS. 
The simplest way to fix them is to use Windows Explorer to show the
properties of the $ldapnew directory, go to the
Security tab, click on the 'Advanced' button on the bottom right,
select the checkbox called 'Replace permission entries on all child
objects with entries shown here that apply to child objects', click
on the 'OK' button and confirm the dialog box.
=====================================================================

END;
